<wfs:FeatureCollection xsi:schemaLocation="http://lgvfds01.fhhnet.stadt.hamburg.de/arcgis/services/FD_FHH_Map/Fussgangerzaehlstellen/MapServer/WFSServer Fussgaengerzaehlstellen.xsd http://www.opengis.net/wfs http://schemas.opengis.net/wfs/1.1.0/wfs.xsd" xmlns:Fussgaengerzaehlstellen="http://lgvfds01.fhhnet.stadt.hamburg.de/arcgis/services/FD_FHH_Map/Fussgangerzaehlstellen/MapServer/WFSServer" xmlns:gml="http://www.opengis.net/gml" xmlns:wfs="http://www.opengis.net/wfs" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
<gml:boundedBy>
<gml:Envelope srsName="urn:ogc:def:crs:EPSG:6.9:25832">
<gml:lowerCorner>551409.10010000039 5922275.5632000007</gml:lowerCorner>
<gml:upperCorner>581653.82670000009 5948504.9749999996</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__1">
<Fussgaengerzaehlstellen:OBJECTID>1</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9001</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Holstenkamp NW Große Bahnstraße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3562048</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5938371</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>561952.91820000019 5936434.8648000006</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__2">
<Fussgaengerzaehlstellen:OBJECTID>2</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9002</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Kanzlershof / Wasmerstraße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3566936</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5924206</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>566838.76099999994 5922275.5632000007</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__3">
<Fussgaengerzaehlstellen:OBJECTID>3</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9003</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Grevenweg / Eiffestraße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3569048</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5936181</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>568950.10099999979 5934245.6038000006</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__4">
<Fussgaengerzaehlstellen:OBJECTID>4</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9004</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Hasenhöhe / Elbchaussee</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3554431</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5936974</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>554338.91280000005 5935038.6241999995</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__5">
<Fussgaengerzaehlstellen:OBJECTID>5</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9005</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Rentzelstraße / Bundesstraße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3564951</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5937610</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>564854.75779999979 5935674.1009999998</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__6">
<Fussgaengerzaehlstellen:OBJECTID>6</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9006</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Ladenbeker Furtweg / Billwerder Billdeich</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3578376</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5930046</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>578274.26580000017 5928112.9309</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__7">
<Fussgaengerzaehlstellen:OBJECTID>7</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9007</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Methfesselstraße / Osterstraße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3562718</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5939086</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>562622.66349999979 5937149.5585999992</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__8">
<Fussgaengerzaehlstellen:OBJECTID>8</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9008</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Otto-Speckter-Straße / Langenfort</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3569366</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5941443</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>569268.05279999971 5939505.4757000003</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__9">
<Fussgaengerzaehlstellen:OBJECTID>9</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9009</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Schwalbenstraße / Hellbrookstraße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3569383</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5940519</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>569285.03199999966 5938581.8471000008</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__10">
<Fussgaengerzaehlstellen:OBJECTID>10</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9010</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Rothenbaumchaussee / Edmund-Siemers-Allee</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3565651</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5937118</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>565554.47329999972 5935182.2826000005</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__11">
<Fussgaengerzaehlstellen:OBJECTID>11</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9011</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Neuer Jungfernstieg / Lombardsbrücke</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3565903</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5936701</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>565806.36730000004 5934765.4450000003</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__12">
<Fussgaengerzaehlstellen:OBJECTID>12</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9012</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Warburgstraße / Alsterufer</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3565941</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5936822</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>565844.35410000011 5934886.3950999994</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__13">
<Fussgaengerzaehlstellen:OBJECTID>13</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9013</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Neumann-Reichardt-Straße W Josephstraße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3571532</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5938461</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>571433.13999999966 5936524.6458999999</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__14">
<Fussgaengerzaehlstellen:OBJECTID>14</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9014</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Hohenzollernring / Bleickenallee</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3560907</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5935909</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>560812.33389999997 5933973.8909000009</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__15">
<Fussgaengerzaehlstellen:OBJECTID>15</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9015</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Hammer Straße NW Claudiusstieg</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3570588</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5937725</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>570489.50710000005 5935788.9570000004</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__16">
<Fussgaengerzaehlstellen:OBJECTID>16</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9016</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Grindelhof / Hartungstraße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3565302</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5938083</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>565205.62590000033 5936146.9009000007</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__17">
<Fussgaengerzaehlstellen:OBJECTID>17</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9017</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Hammer Steindamm N Caspar-Voght-Straße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3570132</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5937592</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>570033.68780000042 5935656.0175999999</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__18">
<Fussgaengerzaehlstellen:OBJECTID>18</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9018</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Gustav-Falke-Straße / Beim Schlump</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3564394</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5937805</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>564297.98120000027 5935869.0359000005</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__19">
<Fussgaengerzaehlstellen:OBJECTID>19</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9019</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Bundesstraße / Beim Schlump</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3564602</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5937970</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>564505.90130000003 5936033.9639999997</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__20">
<Fussgaengerzaehlstellen:OBJECTID>20</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9020</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Bogenstraße / Beim Schlump</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3564825</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5938220</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>564728.81680000015 5936283.8573000003</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__21">
<Fussgaengerzaehlstellen:OBJECTID>21</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9021</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Bebelallee / Braamkamp</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3565909</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5941647</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>565812.43910000008 5939709.4483000003</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__22">
<Fussgaengerzaehlstellen:OBJECTID>22</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9022</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Dritte Meile N Alte Marsch</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3555107</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5927363</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>555014.5055999998 5925431.5285</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__23">
<Fussgaengerzaehlstellen:OBJECTID>23</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9023</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Martinistraße W Curschmannstraße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3564651</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5940135</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>564554.91420000046 5938198.0866</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__24">
<Fussgaengerzaehlstellen:OBJECTID>24</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9024</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Martinistraße O Curschmannstraße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3564685</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5940160</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>564588.90110000037 5938223.0756000001</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__25">
<Fussgaengerzaehlstellen:OBJECTID>25</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9025</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Martinistraße alter Eingang UKE</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3564874</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5940301</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>564777.82849999983 5938364.0139000006</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__26">
<Fussgaengerzaehlstellen:OBJECTID>26</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9026</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Bahnübergang Süderstraße-Klgv.142 N Güterbahn Hamburg</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3570962</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5935362</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>570863.32160000037 5933426.9048999995</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__27">
<Fussgaengerzaehlstellen:OBJECTID>27</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9027</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Heußweg / Osterstraße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3563108</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5938713</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>563012.50370000023 5936776.7000999991</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__28">
<Fussgaengerzaehlstellen:OBJECTID>28</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9028</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Elbchaussee / Schenefelder Landstraße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3554642</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5936882</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>554549.82809999958 5934946.6550999992</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__29">
<Fussgaengerzaehlstellen:OBJECTID>29</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9029</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Alsenstraße / Stresemannstraße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3562936</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5937179</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>562840.54910000041 5935243.3256999999</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__30">
<Fussgaengerzaehlstellen:OBJECTID>30</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9030</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Wrangelstraße / Eppendorfer Weg</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3564284</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5939266</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>564188.04650000017 5937329.4473000001</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__31">
<Fussgaengerzaehlstellen:OBJECTID>31</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9031</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>St.-Pauli-Elbtunnel</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3564143</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5935132</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>564047.04090000037 5933197.1242999993</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__32">
<Fussgaengerzaehlstellen:OBJECTID>32</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9032</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Lerchenfeld NW Eilenau</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3568425</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5937722</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>568327.37380000018 5935785.9908000007</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__33">
<Fussgaengerzaehlstellen:OBJECTID>33</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9033</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Hammer Steindamm / Carl-Petersen-Straße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3569872</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5936709</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>569773.77869999968 5934773.3780000005</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__34">
<Fussgaengerzaehlstellen:OBJECTID>34</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9034</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Osdorfer Landstraße / Rugenbarg</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3556161</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5938266</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>556068.24670000002 5936330.0518999994</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__35">
<Fussgaengerzaehlstellen:OBJECTID>35</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9035</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Bockhorst SW Osdorfer Landstraße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3555907</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5938251</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>555814.3470999999 5936315.0642000008</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__36">
<Fussgaengerzaehlstellen:OBJECTID>36</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9036</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Charlottenburger Straße / Bekkamp</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3575225</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5938771</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>575124.66500000004 5936834.4651999995</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__37">
<Fussgaengerzaehlstellen:OBJECTID>37</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9037</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Jenfelder Allee / Jenfelder Straße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3574732</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5938781</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>574631.86270000041 5936844.4686999992</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__38">
<Fussgaengerzaehlstellen:OBJECTID>38</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9038</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Öjendorfer Damm / Barsbütteler Straße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3575319</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5938325</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>575218.62050000019 5936388.6434000004</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__39">
<Fussgaengerzaehlstellen:OBJECTID>39</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9039</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Steinhauerdamm / Bürgerweide</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3568093</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5936613</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>567995.49010000005 5934677.4439000003</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__40">
<Fussgaengerzaehlstellen:OBJECTID>40</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9040</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Saseler Mühlenweg / Saseler Chaussee</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3573318</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5947712</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>573218.56979999971 5945771.9357999992</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__41">
<Fussgaengerzaehlstellen:OBJECTID>41</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9041</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Halenreie / Farmsener Landstraße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3576893</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5947178</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>576792.13269999996 5945238.0887000002</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__42">
<Fussgaengerzaehlstellen:OBJECTID>42</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9042</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Bahrenfelder Straße / Barner Straße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3561594</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5936481</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>561499.07019999996 5934545.6418999992</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__43">
<Fussgaengerzaehlstellen:OBJECTID>43</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9043</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Veloroute 9 W Bahnhof Nettelnburg</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3578426</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5929194</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>578324.2341 5927261.2863999996</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__44">
<Fussgaengerzaehlstellen:OBJECTID>44</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9044</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Holzmühlenstraße / Auf dem Königslande</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3571647</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5939384</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>571548.10780000035 5937447.2718000002</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__45">
<Fussgaengerzaehlstellen:OBJECTID>45</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9045</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Sieker Landstraße NO Merkurring</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3578947</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5942650</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>578845.23120000027 5940711.8538000006</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__46">
<Fussgaengerzaehlstellen:OBJECTID>46</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9046</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Pillauer Straße NO Voßkulen</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3572008</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5940863</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>571908.98560000025 5938925.6699999999</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__47">
<Fussgaengerzaehlstellen:OBJECTID>47</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9047</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Tilsiter Straße SW Voßkulen</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3572073</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5940539</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>571973.95459999982 5938601.7996999994</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__48">
<Fussgaengerzaehlstellen:OBJECTID>48</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9048</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Pinneberger Chaussee / Halstenbeker Weg</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3559183</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5942981</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>559089.12129999977 5941043.0833999999</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__49">
<Fussgaengerzaehlstellen:OBJECTID>49</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9049</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Fahrenort O Jevenstedter Straße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3557947</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5941367</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>557853.58469999954 5939429.7519000005</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__50">
<Fussgaengerzaehlstellen:OBJECTID>50</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9050</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Heinrich-Stubbe-Weg / Neuengammer Hausdeich</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3581757</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5924425</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>581653.82670000009 5922494.2251999993</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__51">
<Fussgaengerzaehlstellen:OBJECTID>51</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9051</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Kattjahren O Halenreie</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3576858</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5947394</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>576757.15029999986 5945454.0034999996</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__52">
<Fussgaengerzaehlstellen:OBJECTID>52</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9052</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Stephanstraße / Walddörferstraße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3572164</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5939405</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>572064.90099999961 5937468.2556999996</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__53">
<Fussgaengerzaehlstellen:OBJECTID>53</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9053</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Korachstraße O Perelstraße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3579937</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5931722</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>579834.65919999965 5929788.2268000003</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__54">
<Fussgaengerzaehlstellen:OBJECTID>54</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9054</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Leuschnerstraße S Perelstraße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3579599</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5931460</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>579496.7918999996 5929526.3377999999</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__55">
<Fussgaengerzaehlstellen:OBJECTID>55</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9055</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Leuschnerstraße NW Binnenfeldredder</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3579978</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5930965</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>579875.63069999963 5929031.5306000002</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__56">
<Fussgaengerzaehlstellen:OBJECTID>56</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9056</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Gärtnerstraße SW Wrangelstraße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3564052</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5939351</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>563956.13960000034 5937414.4186000004</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__57">
<Fussgaengerzaehlstellen:OBJECTID>57</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9057</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Billstedter Hauptstraße / Billstedter Mühlenweg</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3574026</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5934109</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>573926.07479999959 5932174.3618999999</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__58">
<Fussgaengerzaehlstellen:OBJECTID>58</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9058</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Krohnstieg O Ermlandweg</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3565701</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5946867</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>565604.59869999997 5944927.3959999997</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__59">
<Fussgaengerzaehlstellen:OBJECTID>59</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9059</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Klostergarten / Harvestehuder Weg</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3565872</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5939178</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>565775.41679999977 5937241.4438000005</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__60">
<Fussgaengerzaehlstellen:OBJECTID>60</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9060</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Georg-Wilhelm-Straße/ Trettaustraße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3565811</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5929571</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>565714.29619999975 5927638.3396000005</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__61">
<Fussgaengerzaehlstellen:OBJECTID>61</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9061</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Hegholt / Haldesdorfer Straße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3571519</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5941582</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>571420.19249999989 5939644.3892000001</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__62">
<Fussgaengerzaehlstellen:OBJECTID>62</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9062</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Julius-Vossler-Straße NO Hugh-Greene-Weg</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3562867</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5940837</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>562771.63040000014 5938899.8457999993</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__63">
<Fussgaengerzaehlstellen:OBJECTID>63</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9063</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Hannoversche Straße / Walter-Dudek-Brücke</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3565761</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5925571</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>565664.25090000033 5923640.0155999996</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__64">
<Fussgaengerzaehlstellen:OBJECTID>64</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9064</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Gründgensstraße W Fritz-Flinte-Ring</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3569508</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5942655</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>569410.01439999975 5940716.9949999992</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__65">
<Fussgaengerzaehlstellen:OBJECTID>65</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9065</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Baron-Voght-Straße N Elbchaussee</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3557362</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5935496</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>557268.73180000018 5933561.1469999999</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__66">
<Fussgaengerzaehlstellen:OBJECTID>66</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9066</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Teufelsbrück Ost S Elbchaussee</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3557366</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5935474</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>557272.72989999969 5933539.1558999997</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__67">
<Fussgaengerzaehlstellen:OBJECTID>67</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9067</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Elbchaussee W Baron-Voght-Straße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3557346</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5935476</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>557252.73780000024 5933541.1556000002</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__68">
<Fussgaengerzaehlstellen:OBJECTID>68</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9068</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Hans-Leip-Ufer O Teufelsbrück Ost</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3557391</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5935477</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>557297.71999999974 5933542.1539999992</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__69">
<Fussgaengerzaehlstellen:OBJECTID>69</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9069</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Elbchaussee O Teufelsbrück West</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3557302</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5935457</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>557208.75499999989 5933522.1644000001</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__70">
<Fussgaengerzaehlstellen:OBJECTID>70</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9070</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Elbuferweg W Teufelsbrück West</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3557249</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5935427</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>557155.77560000028 5933492.1778999995</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__71">
<Fussgaengerzaehlstellen:OBJECTID>71</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9071</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Christian-F.-Hansen-Straße N Elbchaussee</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3557026</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5935538</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>556932.86550000031 5933603.1383999996</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__72">
<Fussgaengerzaehlstellen:OBJECTID>72</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9072</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Elbchaussee O Christian-F.-Hansen-Straße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3557034</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5935516</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>556940.86199999973 5933581.1470999997</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__73">
<Fussgaengerzaehlstellen:OBJECTID>73</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9073</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Sieker Landstraße O Rahlstedter Kamp</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3577782</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5942373</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>577680.69550000038 5940434.9821000006</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__74">
<Fussgaengerzaehlstellen:OBJECTID>74</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9074</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Gründgensstraße SW Erich-Ziegel-Ring</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3570476</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5942822</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>570377.62939999998 5940883.9145999998</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__75">
<Fussgaengerzaehlstellen:OBJECTID>75</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9075</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Gründgensstraße SW Borchertring</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3570660</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5943059</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>570561.55939999968 5941120.8181999996</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__76">
<Fussgaengerzaehlstellen:OBJECTID>76</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9076</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Berner Heerweg / Ebeersreye</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3573882</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5941004</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>573782.2368999999 5939066.5856999997</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__77">
<Fussgaengerzaehlstellen:OBJECTID>77</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9077</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Berner Heerweg / Walddörfer Straße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3573602</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5940743</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>573502.34509999957 5938805.6950000003</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__78">
<Fussgaengerzaehlstellen:OBJECTID>78</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9078</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Bremer Straße SW Steinikestraße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3564951</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5925279</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>564854.56749999989 5923348.1570999995</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__79">
<Fussgaengerzaehlstellen:OBJECTID>79</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9079</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Plöner Straße O Schleswiger Straße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3561946</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5937663</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>561850.94820000045 5935727.1542000007</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__80">
<Fussgaengerzaehlstellen:OBJECTID>80</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9080</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Bullenkoppel / Am Stadtrand</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3572763</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5940797</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>572663.68209999986 5938859.6855999995</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__81">
<Fussgaengerzaehlstellen:OBJECTID>81</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9081</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Bergstedter Chaussee / Immenhorstweg</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3574108</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5948729</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>574008.2706000004 5946788.5198999997</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__82">
<Fussgaengerzaehlstellen:OBJECTID>82</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9082</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Moorreye / Flughafenstraße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3567538</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5945921</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>567440.85190000013 5943981.7366000004</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__83">
<Fussgaengerzaehlstellen:OBJECTID>83</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9083</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Peutestraße / Veddeler Brückenstraße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3567988</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5933426</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>567890.48440000042 5931491.7331000008</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__84">
<Fussgaengerzaehlstellen:OBJECTID>84</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9084</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Prielstraße / Veddeler Marktplatz</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3567884</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5933610</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>567786.52880000044 5931675.6603999995</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__85">
<Fussgaengerzaehlstellen:OBJECTID>85</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9085</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Tunnelstraße / Veddeler Marktplatz</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3567832</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5933491</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>567734.54789999966 5931556.7093000002</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__86">
<Fussgaengerzaehlstellen:OBJECTID>86</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9086</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Meiendorfer Straße / Grönländer Damm</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3577343</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5944267</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>577241.90390000027 5942328.2369999997</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__87">
<Fussgaengerzaehlstellen:OBJECTID>87</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9087</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Meiendorfer Straße SW Starckweg</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3576970</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5943773</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>576869.04530000035 5941834.4389999993</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__88">
<Fussgaengerzaehlstellen:OBJECTID>88</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9088</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Bernstorffstraße / Paul-Roosen-Straße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3563482</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5936195</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>563386.31840000022 5934259.7105</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__89">
<Fussgaengerzaehlstellen:OBJECTID>89</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9089</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Veritaskai / Schellerdamm</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3565615</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5926506</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>565518.32400000002 5924574.6276999991</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__90">
<Fussgaengerzaehlstellen:OBJECTID>90</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9090</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Rothenburgstraße / Ausschläger Allee</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3570009</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5933886</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>569910.68130000029 5931951.5154999997</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__91">
<Fussgaengerzaehlstellen:OBJECTID>91</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9091</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Bahnhof Altona</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3562040</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5936051</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>561944.88729999959 5934115.8049999997</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__92">
<Fussgaengerzaehlstellen:OBJECTID>92</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9092</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Anderheitsallee W Bramfelder Chaussee</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3571604</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5943760</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>571505.19249999989 5941821.5266999993</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__93">
<Fussgaengerzaehlstellen:OBJECTID>93</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9093</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Veloroute 9 / Mittlerer Landweg</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3575269</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5930220</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>575168.5175999999 5928286.9090999998</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__94">
<Fussgaengerzaehlstellen:OBJECTID>94</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9094</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Oldenfelder Straße N Eggerskamp</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3576617</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5942788</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>576516.17019999959 5940849.8353000004</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__95">
<Fussgaengerzaehlstellen:OBJECTID>95</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9095</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Ludwig-Erhard-Straße O Englische Planke</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3564987</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5935749</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>564890.71580000035 5933813.8531999998</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__96">
<Fussgaengerzaehlstellen:OBJECTID>96</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9096</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Langenhorner Chaussee N Bärenhof</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3566173</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5950326</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>566076.46239999961 5948385.0228000004</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__97">
<Fussgaengerzaehlstellen:OBJECTID>97</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9097</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Langenhorner Chaussee / Stockflethweg</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3566183</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5950238</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>566086.45710000023 5948297.0572999995</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__98">
<Fussgaengerzaehlstellen:OBJECTID>98</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9098</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Washingtonallee SO Hasencleverstraße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3572221</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5936036</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>572121.8273 5934100.6133999992</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__99">
<Fussgaengerzaehlstellen:OBJECTID>99</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9099</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Washingtonallee SO Stengelestraße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3572365</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5935828</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>572265.76640000008 5933892.6951000001</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__100">
<Fussgaengerzaehlstellen:OBJECTID>100</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9100</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Washingtonallee SO Vierbergen</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3572510</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5935560</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>572410.70430000033 5933624.8008999992</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__101">
<Fussgaengerzaehlstellen:OBJECTID>101</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9101</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Franzosenkoppel / Spreestraße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3558342</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5941410</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>558248.4291000003 5939472.7254000008</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__102">
<Fussgaengerzaehlstellen:OBJECTID>102</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9102</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Flurstraße / Blomkamp</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3557446</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5938942</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>557352.74780000001 5937005.7459999993</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__103">
<Fussgaengerzaehlstellen:OBJECTID>103</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9103</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Geranienweg / Flurstraße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3557434</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5938832</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>557340.75100000016 5936895.7909999993</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__104">
<Fussgaengerzaehlstellen:OBJECTID>104</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9104</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Kleiner Burstah / Willy-Brandt-Straße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3565614</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5935544</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>565517.46439999994 5933608.9203999992</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__105">
<Fussgaengerzaehlstellen:OBJECTID>105</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9105</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Heinrich-Plett-Straße / Ostermeyerstraße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3557472</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5937788</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>557378.7209999999 5935852.2138</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__106">
<Fussgaengerzaehlstellen:OBJECTID>106</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9106</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Sülldorfer Landstraße / Sülldorfer Brooksweg</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3551567</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5939056</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>551476.07459999993 5937119.8654999994</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__107">
<Fussgaengerzaehlstellen:OBJECTID>107</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9107</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Alte Sülldorfer Landstraße / Sülldorfer Brooksweg</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3551500</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5938983</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>551409.10010000039 5937046.8971999995</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__108">
<Fussgaengerzaehlstellen:OBJECTID>108</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9108</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Billhorner Brückenstraße / Zweibrückenstraße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3568210</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5934058</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>568112.40490000043 5932123.4743000008</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__109">
<Fussgaengerzaehlstellen:OBJECTID>109</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9109</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Reesestraße / Barmbeker Markt</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3568998</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5939244</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>568900.1671000002 5937307.3675999995</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__110">
<Fussgaengerzaehlstellen:OBJECTID>110</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9110</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Unterführung unter Karnapp und Buxtehuder Straße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3565232</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5926268</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>565135.4720999999 5924336.7366000004</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__111">
<Fussgaengerzaehlstellen:OBJECTID>111</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9111</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Neuenfelder Hauptdeich / Neuenfelder Damm</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3553448</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5933471</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>553356.25169999991 5931537.0791999996</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__112">
<Fussgaengerzaehlstellen:OBJECTID>112</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9112</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Cranzer Hauptdeich / Estedeich</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3551884</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5934314</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>551792.88169999979 5932379.7852999996</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__113">
<Fussgaengerzaehlstellen:OBJECTID>113</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9113</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Högenstraße / Steenwisch</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3562239</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5939389</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>562143.85759999976 5937452.4476999994</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__114">
<Fussgaengerzaehlstellen:OBJECTID>114</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9114</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Sander Damm / Vierlandenstraße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3580327</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5928768</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>580224.45930000022 5926835.4332999997</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__115">
<Fussgaengerzaehlstellen:OBJECTID>115</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9115</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Helgoländer Allee / St. Pauli Hafenstraße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3564326</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5935386</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>564229.97219999973 5933451.0167999994</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__116">
<Fussgaengerzaehlstellen:OBJECTID>116</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9116</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Karnapp W Harburger Schloßstraße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3565290</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5926276</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>565193.44919999968 5924344.7318999991</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__117">
<Fussgaengerzaehlstellen:OBJECTID>117</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9117</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Hafentor / Ditmar-Koel-Straße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3564553</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5935326</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>564456.8814000003 5933391.0353999995</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__118">
<Fussgaengerzaehlstellen:OBJECTID>118</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9118</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Fischers Allee / Bernadottestraße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3561196</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5935586</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>561101.21470000036 5933651.0145999994</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__119">
<Fussgaengerzaehlstellen:OBJECTID>119</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9119</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Wendemuthstraße / Rüterstraße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3571271</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5938667</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>571172.24770000018 5936730.5667000003</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__120">
<Fussgaengerzaehlstellen:OBJECTID>120</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9120</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Wendemuthstraße / Wandsbeker Zollstraße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3571239</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5938705</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>571140.26109999977 5936768.5517999995</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__121">
<Fussgaengerzaehlstellen:OBJECTID>121</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9121</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Wegnr.10168 unben. Straße N Rotenhäuser Straße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3566297</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5930957</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>566200.125 5929023.7585000005</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__122">
<Fussgaengerzaehlstellen:OBJECTID>122</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9122</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Nettelnburger Landweg S Nettelnburger Straße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3578382</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5928039</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>578280.23639999982 5926106.7700999994</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__123">
<Fussgaengerzaehlstellen:OBJECTID>123</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9123</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Wilstorfer Straße / Hannoversche Straße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3565671</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5924921</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>565574.27599999961 5922990.2898999993</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__124">
<Fussgaengerzaehlstellen:OBJECTID>124</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9124</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Binnenfeldredder NO Max-Eichholz-Ring (LG)</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3581125</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5931113</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>581022.16860000044 5929179.4520999994</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__125">
<Fussgaengerzaehlstellen:OBJECTID>125</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9125</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Dorotheenstraße / Krohnskamp</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3566699</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5939864</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>566602.09740000032 5937927.1508000009</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__126">
<Fussgaengerzaehlstellen:OBJECTID>126</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9126</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Kollaustraße / Osterfeldstraße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3563887</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5941360</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>563791.23469999991 5939422.6107999999</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__127">
<Fussgaengerzaehlstellen:OBJECTID>127</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9127</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Buxtehuder Straße W Neue Straße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3565182</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5926272</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>565085.49199999962 5924340.7360999994</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__128">
<Fussgaengerzaehlstellen:OBJECTID>128</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9128</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Holstenglacis / Sievekingplatz</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3564697</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5936549</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>564600.84260000009 5934613.5368000008</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__129">
<Fussgaengerzaehlstellen:OBJECTID>129</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9129</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Wandsbeker Allee / Wandsbeker Marktstraße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3570975</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5938494</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>570876.36369999964 5936557.6409000009</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__130">
<Fussgaengerzaehlstellen:OBJECTID>130</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9130</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Elbchaussee W Rulantweg</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3560496</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5935346</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>560401.48840000015 5933411.1294999998</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__131">
<Fussgaengerzaehlstellen:OBJECTID>131</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9131</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Reclamstraße O Billstedter Platz (West)</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3573403</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5935107</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>573303.33949999977 5933171.9695999995</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__132">
<Fussgaengerzaehlstellen:OBJECTID>132</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9132</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Fritzschweg / Reclamstraße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3573470</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5935068</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>573370.31209999975 5933132.9842000008</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__133">
<Fussgaengerzaehlstellen:OBJECTID>133</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9133</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Billstedter Platz (Ost) N Reclamstraße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3573501</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5935073</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>573401.29980000015 5933137.9816999994</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__134">
<Fussgaengerzaehlstellen:OBJECTID>134</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9134</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Uferstraße NO Lerchenfeld</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3568481</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5937819</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>568383.35280000046 5935882.9507999998</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__135">
<Fussgaengerzaehlstellen:OBJECTID>135</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9135</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Lerchenfeld SW Uferstraße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3568401</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5937755</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>568303.38389999978 5935818.9779000003</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__136">
<Fussgaengerzaehlstellen:OBJECTID>136</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9136</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Wagnerstraße SW Uferstraße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3568953</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5938237</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>568855.1699000001 5936300.7749000005</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__137">
<Fussgaengerzaehlstellen:OBJECTID>137</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9137</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Schwanenwik S Hartwicusstraße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3567440</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5937605</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>567342.76669999957 5935669.0528999995</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__138">
<Fussgaengerzaehlstellen:OBJECTID>138</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9138</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Schöne Aussicht NW Auguststraße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3566992</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5938088</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>566894.9534 5936151.8643999994</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__139">
<Fussgaengerzaehlstellen:OBJECTID>139</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9139</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Bellevue N Scheffelstraße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3566554</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5939029</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>566457.14300000016 5937092.4904999994</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__140">
<Fussgaengerzaehlstellen:OBJECTID>140</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9140</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Vierlandenstraße / Bergedorfer Straße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3580431</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5929099</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>580328.42150000017 5927166.2931999993</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__141">
<Fussgaengerzaehlstellen:OBJECTID>141</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9141</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Jenfelder Straße SO Am Grundwasserwerk</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3573535</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5939100</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>573435.3470999999 5937163.3582000006</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__142">
<Fussgaengerzaehlstellen:OBJECTID>142</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9142</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Wellingsbüttler Landstraße / Fuhlsbüttler Straße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3568310</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5944327</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>568212.51919999998 5942388.3532999996</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__143">
<Fussgaengerzaehlstellen:OBJECTID>143</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9143</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Erdkampsweg / Brombeerweg</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3567975</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5944375</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>567877.65390000027 5942436.3395000007</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__144">
<Fussgaengerzaehlstellen:OBJECTID>144</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9144</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Hummelsbüttler Landstraße / Brombeerweg</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3567970</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5944695</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>567872.66069999989 5942756.2134000007</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__145">
<Fussgaengerzaehlstellen:OBJECTID>145</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9145</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Erdkampsweg / Hummelsbüttler Landstraße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3567875</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5944517</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>567777.69610000029 5942578.2850000001</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__146">
<Fussgaengerzaehlstellen:OBJECTID>146</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9146</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Erdkampsweg / Ratsmühlendamm</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3567898</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5944379</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>567800.68479999993 5942440.3390999995</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__147">
<Fussgaengerzaehlstellen:OBJECTID>147</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9147</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Kieler Straße / Sola-Bona-Park</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3560603</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5941489</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>560508.53589999955 5939551.6394999996</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__148">
<Fussgaengerzaehlstellen:OBJECTID>148</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9148</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Frickestraße / Martinistraße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3565051</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5940429</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>564954.76040000003 5938491.9578000009</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__149">
<Fussgaengerzaehlstellen:OBJECTID>149</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9149</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Hammer Steindamm S Bei der Hammer Kirche</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3569868</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5936585</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>569769.77850000001 5934649.4280999992</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__150">
<Fussgaengerzaehlstellen:OBJECTID>150</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9150</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Ulzburger Straße / Poppenbütteler Weg</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3571298</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5947407</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>571199.37189999968 5945467.0895000007</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__151">
<Fussgaengerzaehlstellen:OBJECTID>151</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9151</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Billbrookdeich / Liebigstraße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3571477</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5934358</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>571378.10010000039 5932423.3018999994</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__152">
<Fussgaengerzaehlstellen:OBJECTID>152</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9153</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Fritz-Flinte-Ring / Gründgensstraße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3569717</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5942596</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>569618.92980000004 5940658.0152000003</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__153">
<Fussgaengerzaehlstellen:OBJECTID>153</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9154</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Gropiusring / Gründgensstraße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3569859</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5942562</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>569760.87239999976 5940624.0264999997</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__154">
<Fussgaengerzaehlstellen:OBJECTID>154</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9155</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Schreyerring / Cesar-Klein-Ring (West)</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3570093</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5942610</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>569994.77950000018 5940672.0041000005</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__155">
<Fussgaengerzaehlstellen:OBJECTID>155</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9156</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Schreyerring / Cesar-Klein-Ring (Ost)</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3570211</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5942647</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>570112.73280000035 5940708.9877000004</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__156">
<Fussgaengerzaehlstellen:OBJECTID>156</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9157</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Gründgensstraße / Gustav-Seitz-Weg</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3570347</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5942683</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>570248.67889999971 5940744.9714000002</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__157">
<Fussgaengerzaehlstellen:OBJECTID>157</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9158</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Bergstraße / Mönckebergstraße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3566072</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5935920</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>565975.28870000038 5933984.7566999998</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__158">
<Fussgaengerzaehlstellen:OBJECTID>158</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9159</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Rübenkamp N Andreas-Knack-Ring</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3568558</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5942017</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>568460.38509999961 5940079.2609999999</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__159">
<Fussgaengerzaehlstellen:OBJECTID>159</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9160</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Gert-Schwämmle-Weg / Georg-Wilhelm-Straße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3565878</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5930641</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>565781.28639999963 5928707.8972999994</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__160">
<Fussgaengerzaehlstellen:OBJECTID>160</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9161</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Bornheide (vor Haus Nr. 43)</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3556481</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5939732</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>556388.1409 5937795.4486999996</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__161">
<Fussgaengerzaehlstellen:OBJECTID>161</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9162</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Bornheide S Kroonhorst (Süd)</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3556483</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5939949</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>556390.14319999982 5938012.3605000004</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__162">
<Fussgaengerzaehlstellen:OBJECTID>162</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9163</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Glückstädter Weg S Kroonhorst (Nord)</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3556519</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5940255</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>556426.1333999997 5938318.2354000006</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__163">
<Fussgaengerzaehlstellen:OBJECTID>163</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9164</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Bornheide N Kroonhorst (Nord)</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3556536</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5940452</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>556443.12939999998 5938515.1549999993</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__164">
<Fussgaengerzaehlstellen:OBJECTID>164</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9165</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Gaußstraße / Barnerstraße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3561871</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5936608</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>561775.96239999961 5934672.5834999997</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__165">
<Fussgaengerzaehlstellen:OBJECTID>165</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9166</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Julius-Leber-Straße O Barnerstraße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3561993</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5936425</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>561897.91139999963 5934489.6546</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__166">
<Fussgaengerzaehlstellen:OBJECTID>166</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9167</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Harkortstraße / Julius-Leber-Straße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3562111</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5936442</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>562015.86490000039 5934506.6447999999</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__167">
<Fussgaengerzaehlstellen:OBJECTID>167</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9168</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Haubachstraße NO Julius-Leber-Straße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3562148</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5936450</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>562052.85039999988 5934514.6405999996</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__168">
<Fussgaengerzaehlstellen:OBJECTID>168</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9169</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Rugenbarg / Blomkamp</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3556176</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5938635</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>556083.24600000028 5936698.9015999995</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__169">
<Fussgaengerzaehlstellen:OBJECTID>169</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9170</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Halenreie / Waldweg (Nord)</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3576802</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5947614</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>576701.17640000023 5945673.9170999993</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__170">
<Fussgaengerzaehlstellen:OBJECTID>170</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9171</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Halenreie / Waldweg (Süd)</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3576812</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5947491</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>576711.17030000035 5945550.9658000004</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__171">
<Fussgaengerzaehlstellen:OBJECTID>171</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9174</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Winsener Straße / Reeseberg</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3565679</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5924742</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>565582.26989999972 5922811.3646000009</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__172">
<Fussgaengerzaehlstellen:OBJECTID>172</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9176</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Salomon-Heine-Weg / Meenkwiese</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3565576</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5941191</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>565479.56410000008 5939253.6367000006</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__173">
<Fussgaengerzaehlstellen:OBJECTID>173</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9177</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Vahrenwinkelweg / Ehestorfer Weg</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3562276</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5925214</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>562180.62770000007 5923283.2476000004</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__174">
<Fussgaengerzaehlstellen:OBJECTID>174</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9178</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Fuhlsbüttler Straße / Elligersweg</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3568909</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5942033</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>568811.24480000045 5940095.2495000008</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__175">
<Fussgaengerzaehlstellen:OBJECTID>175</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9179</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Carl-Cohn-Straße / Alsterdorfer Straße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3566599</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5942227</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>566502.1727 5940289.2070000004</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__176">
<Fussgaengerzaehlstellen:OBJECTID>176</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9180</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Saseler Damm / Stadtbahnstraße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3573029</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5947453</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>572929.6810999997 5945513.0429999996</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__177">
<Fussgaengerzaehlstellen:OBJECTID>177</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9181</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Eekbusch N Stadtbahnstraße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3573109</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5947476</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>573009.64950000029 5945536.0326000005</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__178">
<Fussgaengerzaehlstellen:OBJECTID>178</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9183</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Lohmühlenstraße / Barcastraße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3567316</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5937022</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>567218.80759999994 5935086.2904000003</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__179">
<Fussgaengerzaehlstellen:OBJECTID>179</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9184</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Langenhorner Chaussee / Am Ochsenzoll</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3566203</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5950446</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>566106.45220000017 5948504.9749999996</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__180">
<Fussgaengerzaehlstellen:OBJECTID>180</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9185</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Leinpfad / Maria-Louisen-Straße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3566027</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5939618</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>565930.36199999973 5937681.2620000001</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__181">
<Fussgaengerzaehlstellen:OBJECTID>181</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9186</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Rübenkamp N Genslerstraße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3568808</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5940678</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>568710.26470000017 5938740.7913000006</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__182">
<Fussgaengerzaehlstellen:OBJECTID>182</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9187</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Eppendorfer Baum / Klosterstern</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3565491</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5939414</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>565394.57110000029 5937477.3576999996</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__183">
<Fussgaengerzaehlstellen:OBJECTID>183</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9188</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Oderfelder Straße / Klosterstern</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3565539</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5939443</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>565442.55250000022 5937506.3447999991</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__184">
<Fussgaengerzaehlstellen:OBJECTID>184</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9189</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>St. Benedictstraße / Klosterstern</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3565602</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5939405</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>565505.52699999977 5937468.3585999999</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__185">
<Fussgaengerzaehlstellen:OBJECTID>185</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9190</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Harvestehuder Weg / Klosterstern</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3565592</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5939333</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>565495.52990000043 5937396.3880000003</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__186">
<Fussgaengerzaehlstellen:OBJECTID>186</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9191</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Rothenbaumchaussee / Klosterstern</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3565551</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5939311</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>565454.54580000043 5937374.3979000002</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__187">
<Fussgaengerzaehlstellen:OBJECTID>187</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9192</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Jungfrauental / Klosterstern</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3565490</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5939343</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>565393.57039999962 5937406.3863999993</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__188">
<Fussgaengerzaehlstellen:OBJECTID>188</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9193</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Eppendorfer Baum / Isestraße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3565297</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5939551</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>565200.64989999961 5937614.307</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__189">
<Fussgaengerzaehlstellen:OBJECTID>189</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9194</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Wandse Wanderweg (Querung Wandsbeker Allee)</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3570953</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5938805</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>570854.37719999999 5936868.5157999992</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__190">
<Fussgaengerzaehlstellen:OBJECTID>190</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9196</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Uferstraße NO Wagnerstraße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3568982</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5938255</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>568884.15859999973 5936318.7672000006</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__191">
<Fussgaengerzaehlstellen:OBJECTID>191</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9197</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Eimsbütteler Chaussee / Schulterblatt</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3563593</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5937563</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>563497.29470000044 5935627.1537999995</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__192">
<Fussgaengerzaehlstellen:OBJECTID>192</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9198</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Gert-Schwämmle-Weg NW Dratelnstraße (Unterführung Wilhelmsburger Reichsstraße, &quot;Loop&quot;)</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3566432</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5930207</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>566335.05989999976 5928274.0592</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__193">
<Fussgaengerzaehlstellen:OBJECTID>193</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9199</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Ellmenreichstraße O Kirchenallee</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3566929</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5936329</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>566831.9523 5934393.5763000008</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__194">
<Fussgaengerzaehlstellen:OBJECTID>194</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9200</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Kirchenallee N Ernst-Merck-Straße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3566869</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5936435</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>566771.97790000029 5934499.5343999993</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__195">
<Fussgaengerzaehlstellen:OBJECTID>195</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9201</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Holzdamm N Ernst-Merck-Straße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3566765</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5936409</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>566668.01919999998 5934473.5464999992</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__196">
<Fussgaengerzaehlstellen:OBJECTID>196</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9202</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Ernst-Merck-Straße SW Holzdamm</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3566719</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5936375</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>566622.03720000014 5934439.5609000009</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__197">
<Fussgaengerzaehlstellen:OBJECTID>197</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9203</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Glockengießerwall NW Ernst-Merck-Straße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3566568</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5936333</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>566471.09700000007 5934397.5801999997</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__198">
<Fussgaengerzaehlstellen:OBJECTID>198</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9204</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Georgsplatz SW Glockengießerwall</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3566544</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5936263</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>566447.10560000036 5934327.6088999994</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__199">
<Fussgaengerzaehlstellen:OBJECTID>199</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9205</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Spitaler Straße SW Steintorwall</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3566675</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5936157</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>566578.05150000006 5934221.6497000009</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__200">
<Fussgaengerzaehlstellen:OBJECTID>200</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9206</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Mönckebergstraße W Steintorwall</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3566675</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5936048</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>566578.04989999998 5934112.6938000005</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__201">
<Fussgaengerzaehlstellen:OBJECTID>201</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9207</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Steintorwall S Mönckebergstraße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3566741</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5936021</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>566644.02300000004 5934085.7037000004</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__202">
<Fussgaengerzaehlstellen:OBJECTID>202</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9208</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Steintordamm O Steintorwall</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3566791</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5936067</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>566694.00370000023 5934131.6842999998</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__203">
<Fussgaengerzaehlstellen:OBJECTID>203</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9209</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Julius-Kober-Weg S Steintordamm</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3566916</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5936044</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>566818.95330000017 5934108.6917000003</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__204">
<Fussgaengerzaehlstellen:OBJECTID>204</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9210</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Brockesstraße S Steintorplatz</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3567007</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5936069</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>566909.91720000003 5934133.6801999994</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__205">
<Fussgaengerzaehlstellen:OBJECTID>205</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9211</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>ZOB (Hbf) Zugang O Brockesstraße</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3567042</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5936067</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>566944.90309999976 5934131.6805000007</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__206">
<Fussgaengerzaehlstellen:OBJECTID>206</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9212</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Adenauerallee O Steindamm</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3567057</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5936121</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>566959.89790000021 5934185.6585000008</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__207">
<Fussgaengerzaehlstellen:OBJECTID>207</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9213</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Steindamm NO Steintorplatz</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3567032</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5936166</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>566934.90859999973 5934230.6405999996</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__208">
<Fussgaengerzaehlstellen:OBJECTID>208</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9214</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Steintorweg N Steintorplatz</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3566978</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5936175</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>566880.93039999995 5934239.6378000006</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__209">
<Fussgaengerzaehlstellen:OBJECTID>209</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9215</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Bremer Reihe O Kirchenallee</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3566932</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5936257</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>566834.95000000019 5934321.6053999998</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__210">
<Fussgaengerzaehlstellen:OBJECTID>210</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9216</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Hauptbahnhof - Zugang Ostseite (Mitte)</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3566854</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5936231</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>566756.98089999985 5934295.6171000004</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__211">
<Fussgaengerzaehlstellen:OBJECTID>211</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9217</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Hauptbahnhof - Zugang Ostseite (Nord)</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3566848</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5936270</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>566750.98390000034 5934334.6013999991</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__212">
<Fussgaengerzaehlstellen:OBJECTID>212</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9218</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Hauptbahnhof - Zugang Westseite (Nord)</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3566706</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5936214</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>566609.03990000021 5934278.6261999998</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__213">
<Fussgaengerzaehlstellen:OBJECTID>213</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9219</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Hauptbahnhof - Zugang Westseite (Süd)</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3566754</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5936086</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>566657.01879999973 5934150.6772000007</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle gml:id="F4__214">
<Fussgaengerzaehlstellen:OBJECTID>214</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Zaehlstelle>9220</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Name>Hauptbahnhof - Zugang Ostseite (Süd)</Fussgaengerzaehlstellen:Name>
<Fussgaengerzaehlstellen:X>3566887</Fussgaengerzaehlstellen:X>
<Fussgaengerzaehlstellen:Y>5936119</Fussgaengerzaehlstellen:Y>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>566789.96600000001 5934183.6619000006</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstelle>
</gml:featureMember>
</wfs:FeatureCollection>