<wfs:FeatureCollection xsi:schemaLocation="http://lgvfds01.fhhnet.stadt.hamburg.de/arcgis/services/FD_FHH_Map/Fussgangerzaehlstellen/MapServer/WFSServer Fussgaengerzaehlstellen.xsd http://www.opengis.net/wfs http://schemas.opengis.net/wfs/1.1.0/wfs.xsd" xmlns:Fussgaengerzaehlstellen="http://lgvfds01.fhhnet.stadt.hamburg.de/arcgis/services/FD_FHH_Map/Fussgangerzaehlstellen/MapServer/WFSServer" xmlns:gml="http://www.opengis.net/gml" xmlns:wfs="http://www.opengis.net/wfs" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
<gml:boundedBy>
<gml:Envelope srsName="urn:ogc:def:crs:EPSG:6.9:25832">
<gml:lowerCorner>551409.23840000015 5922275.5734000001</gml:lowerCorner>
<gml:upperCorner>581653.95289999992 5948505.1409000009</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__1">
<Fussgaengerzaehlstellen:OBJECTID>1</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>561953.03010000009 5936435.0157999992</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Holstenkamp NW Große Bahnstraße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9001</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>1996-05-31T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__2">
<Fussgaengerzaehlstellen:OBJECTID>2</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>566838.84939999972 5922275.5734000001</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Kanzlershof / Wasmerstraße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9002</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>1996-11-08T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__3">
<Fussgaengerzaehlstellen:OBJECTID>3</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>568950.20749999955 5934245.7714000009</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Grevenweg / Eiffestraße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9003</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>1999-01-14T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__4"><Fussgaengerzaehlstellen:OBJECTID>4</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>554339.03859999962 5935038.6981000006</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Hasenhöhe / Elbchaussee</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9004</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>1999-07-06T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__5">
<Fussgaengerzaehlstellen:OBJECTID>5</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>564854.86199999973 5935674.2706000004</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Rentzelstraße / Bundesstraße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9005</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2000-02-01T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__6">
<Fussgaengerzaehlstellen:OBJECTID>6</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>578274.39240000024 5928113.0583999995</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Ladenbeker Furtweg / Billwerder Billdeich</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9006</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2000-02-16T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__7">
<Fussgaengerzaehlstellen:OBJECTID>7</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>562622.77520000003 5937149.7201000005</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Methfesselstraße / Osterstraße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9007</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2000-05-09T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__8">
<Fussgaengerzaehlstellen:OBJECTID>8</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>569268.16839999985 5939505.6715999991</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Otto-Speckter-Straße / Langenfort</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9008</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2000-11-02T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__9">
<Fussgaengerzaehlstellen:OBJECTID>9</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>569285.14620000031 5938582.0391000006</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Schwalbenstraße / Hellbrookstraße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9009</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2000-11-02T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__10">
<Fussgaengerzaehlstellen:OBJECTID>10</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>565554.57519999985 5935182.4548000004</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Rothenbaumchaussee / Edmund-Siemers-Allee</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9010</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2000-10-31T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__11">
<Fussgaengerzaehlstellen:OBJECTID>11</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>565806.46800000034 5934765.6165999994</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Neuer Jungfernstieg / Lombardsbrücke</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9011</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2010-04-13T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__12">
<Fussgaengerzaehlstellen:OBJECTID>12</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>565844.45480000041 5934886.5678000003</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Warburgstraße / Alsterufer</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9012</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2010-04-13T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__13">
<Fussgaengerzaehlstellen:OBJECTID>13</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>571433.25669999979 5936524.8224999998</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Neumann-Reichardt-Straße W Josephstraße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9013</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2000-11-30T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__14">
<Fussgaengerzaehlstellen:OBJECTID>14</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>560812.44340000022 5933974.0146999992</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Hohenzollernring / Bleickenallee</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9014</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2011-08-30T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__15">
<Fussgaengerzaehlstellen:OBJECTID>15</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>570489.62019999977 5935789.1312000006</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Hammer Straße NW Claudiusstieg</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9015</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>1999-09-08T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__16">
<Fussgaengerzaehlstellen:OBJECTID>16</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>565205.73010000028 5936147.0765000004</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Grindelhof / Hartungstraße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9016</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2001-01-23T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__17">
<Fussgaengerzaehlstellen:OBJECTID>17</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>570033.79949999973 5935656.1917000003</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Hammer Steindamm N Caspar-Voght-Straße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9017</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2001-02-21T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__18">
<Fussgaengerzaehlstellen:OBJECTID>18</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>564298.08690000046 5935869.2021999992</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Gustav-Falke-Straße / Beim Schlump</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9018</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2001-04-04T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__19">
<Fussgaengerzaehlstellen:OBJECTID>19</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>564506.00690000039 5936034.1330999993</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Bundesstraße / Beim Schlump</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9019</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2001-04-04T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__20">
<Fussgaengerzaehlstellen:OBJECTID>20</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>564728.92219999991 5936284.0298999995</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Bogenstraße / Beim Schlump</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9020</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2001-04-04T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__21">
<Fussgaengerzaehlstellen:OBJECTID>21</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>565812.5477 5939709.6478000004</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Bebelallee / Braamkamp</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9021</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2001-04-24T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__22">
<Fussgaengerzaehlstellen:OBJECTID>22</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>555014.61050000042 5925431.5125999991</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Dritte Meile N Alte Marsch</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9022</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2001-06-08T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__23">
<Fussgaengerzaehlstellen:OBJECTID>23</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>564555.02329999954 5938198.2705000006</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Martinistraße W Curschmannstraße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9023</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2001-06-07T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__24">
<Fussgaengerzaehlstellen:OBJECTID>24</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>564589.01020000037 5938223.2599999998</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Martinistraße O Curschmannstraße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9024</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2001-06-07T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__25">
<Fussgaengerzaehlstellen:OBJECTID>25</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>564777.93730000034 5938364.2006999999</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Martinistraße alter Eingang UKE</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9025</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2001-06-07T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__26">
<Fussgaengerzaehlstellen:OBJECTID>26</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>570863.43200000003 5933427.0656000003</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Bahnübergang Süderstraße-Klgv.142 N Güterbahn Hamburg</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9026</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2001-07-05T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__27">
<Fussgaengerzaehlstellen:OBJECTID>27</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>563012.6138000004 5936776.8620999996</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Heußweg / Osterstraße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9027</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2001-07-03T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__28">
<Fussgaengerzaehlstellen:OBJECTID>28</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>554549.95309999958 5934946.7312000003</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Elbchaussee / Schenefelder Landstraße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9028</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2002-01-31T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__29">
<Fussgaengerzaehlstellen:OBJECTID>29</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>562840.6568 5935243.4756000005</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Alsenstraße / Stresemannstraße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9029</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2002-09-03T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__30">
<Fussgaengerzaehlstellen:OBJECTID>30</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>564188.15490000043 5937329.6225000005</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Wrangelstraße / Eppendorfer Weg</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9030</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2003-03-26T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__31">
<Fussgaengerzaehlstellen:OBJECTID>31</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>564047.14250000007 5933197.2704000007</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>St.-Pauli-Elbtunnel</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9031</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2003-08-19T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__32">
<Fussgaengerzaehlstellen:OBJECTID>32</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>568327.48110000044 5935786.1682999991</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Lerchenfeld NW Eilenau</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9032</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2004-03-30T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__33">
<Fussgaengerzaehlstellen:OBJECTID>33</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>569773.88829999976 5934773.5474999994</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Hammer Steindamm / Carl-Petersen-Straße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9033</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2004-04-22T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__34">
<Fussgaengerzaehlstellen:OBJECTID>34</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>556068.3713999996 5936330.1552000009</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Osdorfer Landstraße / Rugenbarg</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9034</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2004-06-16T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__35">
<Fussgaengerzaehlstellen:OBJECTID>35</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>555814.47229999956 5936315.1654000003</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Bockhorst SW Osdorfer Landstraße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9035</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2004-06-16T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__36">
<Fussgaengerzaehlstellen:OBJECTID>36</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>575124.7918999996 5936834.6377000008</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Charlottenburger Straße / Bekkamp</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9036</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2004-11-09T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__37">
<Fussgaengerzaehlstellen:OBJECTID>37</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>574631.98830000032 5936844.6418999992</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Jenfelder Allee / Jenfelder Straße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9037</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2004-11-09T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__38">
<Fussgaengerzaehlstellen:OBJECTID>38</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>575218.74700000044 5936388.8136999998</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Öjendorfer Damm / Barsbütteler Straße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9038</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2004-11-09T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__39">
<Fussgaengerzaehlstellen:OBJECTID>39</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>567995.59480000008 5934677.6152999997</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Steinhauerdamm / Bürgerweide</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9039</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2005-06-23T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__40">
<Fussgaengerzaehlstellen:OBJECTID>40</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>573218.69969999976 5945772.1106000002</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Saseler Mühlenweg / Saseler Chaussee</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9040</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2016-04-28T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__41">
<Fussgaengerzaehlstellen:OBJECTID>41</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>576792.26800000016 5945238.2635999992</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Halenreie / Farmsener Landstraße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9041</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2013-08-13T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__42">
<Fussgaengerzaehlstellen:OBJECTID>42</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>561499.17939999979 5934545.7756999992</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Bahrenfelder Straße / Barner Straße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9042</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2016-06-01T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__43">
<Fussgaengerzaehlstellen:OBJECTID>43</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>578324.35830000043 5927261.3968000002</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Unbenannter Weg Nr. 802816 (Veloroute 9) W Friedrich-Frank-Bogen</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9043</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2016-05-10T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__44">
<Fussgaengerzaehlstellen:OBJECTID>44</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>571548.22620000038 5937447.4531999994</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Holzmühlenstraße / Auf dem Königslande</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9044</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2006-05-30T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__45">
<Fussgaengerzaehlstellen:OBJECTID>45</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>578845.375 5940712.0317000002</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Sieker Landstraße NO Merkurring</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9045</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2006-07-03T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__46">
<Fussgaengerzaehlstellen:OBJECTID>46</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>571909.10720000044 5938925.8585000001</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Pillauer Straße NO Voßkulen</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9046</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2004-02-17T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__47">
<Fussgaengerzaehlstellen:OBJECTID>47</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>571974.07589999959 5938601.9864000008</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Tilsiter Straße SW Voßkulen</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9047</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2004-02-17T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__48">
<Fussgaengerzaehlstellen:OBJECTID>48</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>559089.24679999985 5941043.2284999993</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Pinneberger Chaussee / Halstenbeker Weg</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9048</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2004-09-15T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__49">
<Fussgaengerzaehlstellen:OBJECTID>49</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>557853.71200000029 5939429.8914000001</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Fahrenort O Jevenstedter Straße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9049</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2004-02-26T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__50">
<Fussgaengerzaehlstellen:OBJECTID>50</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>581653.95289999992 5922494.2399000004</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Heinrich-Stubbe-Weg / Neuengammer Hausdeich</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9050</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2004-06-22T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__51">
<Fussgaengerzaehlstellen:OBJECTID>51</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>576757.28550000023 5945454.1782000009</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Kattjahren O Halenreie</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9051</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2013-08-13T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__52">
<Fussgaengerzaehlstellen:OBJECTID>52</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>572065.02080000006 5937468.4363000002</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Stephanstraße / Walddörferstraße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9052</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2004-11-02T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__53">
<Fussgaengerzaehlstellen:OBJECTID>53</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>579834.79889999982 5929788.3651999999</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Korachstraße O Perelstraße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9053</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2004-11-23T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__54">
<Fussgaengerzaehlstellen:OBJECTID>54</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>579496.9291000003 5929526.4751999993</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Leuschnerstraße S Perelstraße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9054</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2004-11-23T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__55">
<Fussgaengerzaehlstellen:OBJECTID>55</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>579875.76999999955 5929031.6658999994</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Leuschnerstraße NW Binnenfeldredder</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9055</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2004-12-02T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__56">
<Fussgaengerzaehlstellen:OBJECTID>56</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>563956.24870000035 5937414.5924999993</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Gärtnerstraße SW Wrangelstraße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9056</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2005-02-08T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__57">
<Fussgaengerzaehlstellen:OBJECTID>57</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>573926.19159999955 5932174.5133999996</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Billstedter Hauptstraße / Billstedter Mühlenweg</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9057</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2005-03-31T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__58">
<Fussgaengerzaehlstellen:OBJECTID>58</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>565604.71719999984 5944927.5735999998</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Krohnstieg O Ermlandweg</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9058</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2005-04-05T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember><gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__59">
<Fussgaengerzaehlstellen:OBJECTID>59</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>565775.52139999997 5937241.6312000006</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Klostergarten / Harvestehuder Weg</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9059</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2005-08-24T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__60">
<Fussgaengerzaehlstellen:OBJECTID>60</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>565714.3861999996 5927638.4562999997</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Georg-Wilhelm-Straße/ Trettaustraße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9060</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2005-10-18T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__61">
<Fussgaengerzaehlstellen:OBJECTID>61</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>571420.31369999982 5939644.5804999992</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Hegholt / Haldesdorfer Straße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9061</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2013-11-26T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__62">
<Fussgaengerzaehlstellen:OBJECTID>62</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>562771.74500000011 5938900.0207000002</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Julius-Vossler-Straße NO Hugh-Greene-Weg</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9062</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2005-11-08T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__63">
<Fussgaengerzaehlstellen:OBJECTID>63</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>565664.33980000019 5923640.0494999997</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Hannoversche Straße / Walter-Dudek-Brücke</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9063</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2006-10-10T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__64">
<Fussgaengerzaehlstellen:OBJECTID>64</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>569410.13200000022 5940717.1867999993</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Gründgensstraße W Fritz-Flinte-Ring</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9064</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2012-11-08T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__65">
<Fussgaengerzaehlstellen:OBJECTID>65</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>557268.84750000015 5933561.2379000001</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Baron-Voght-Straße N Elbchaussee</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9065</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2006-11-30T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__66">
<Fussgaengerzaehlstellen:OBJECTID>66</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>557272.84559999965 5933539.2466000002</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Teufelsbrück Ost S Elbchaussee</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9066</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2006-11-30T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__67">
<Fussgaengerzaehlstellen:OBJECTID>67</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>557252.85360000003 5933541.2460999992</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Elbchaussee W Baron-Voght-Straße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9067</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2006-11-30T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__68">
<Fussgaengerzaehlstellen:OBJECTID>68</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>557297.8356999997 5933542.2449999992</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Hans-Leip-Ufer O Teufelsbrück Ost</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9068</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2006-11-30T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__69">
<Fussgaengerzaehlstellen:OBJECTID>69</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>557208.87079999968 5933522.2544</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Elbchaussee O Teufelsbrück West</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9069</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2006-11-30T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__70">
<Fussgaengerzaehlstellen:OBJECTID>70</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>557155.89140000008 5933492.2672000006</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Elbuferweg W Teufelsbrück West</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9070</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2006-11-30T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__71">
<Fussgaengerzaehlstellen:OBJECTID>71</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>556932.98199999984 5933603.2267000005</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Christian-F.-Hansen-Straße N Elbchaussee</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9071</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2006-11-30T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__72">
<Fussgaengerzaehlstellen:OBJECTID>72</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>556940.97840000037 5933581.2354000006</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Elbchaussee O Christian-F.-Hansen-Straße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9072</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2006-11-30T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__73">
<Fussgaengerzaehlstellen:OBJECTID>73</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>577680.83409999963 5940435.1613999996</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Sieker Landstraße O Rahlstedter Kamp</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9073</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2007-02-22T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__74">
<Fussgaengerzaehlstellen:OBJECTID>74</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>570377.74949999992 5940884.1041999999</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Gründgensstraße SW Erich-Ziegel-Ring</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9074</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2007-02-20T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__75">
<Fussgaengerzaehlstellen:OBJECTID>75</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>570561.68020000029 5941121.0067999996</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Gründgensstraße SW Borchertring</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9075</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2007-02-20T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__76">
<Fussgaengerzaehlstellen:OBJECTID>76</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>573782.36359999981 5939066.7711999994</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Berner Heerweg / Ebeersreye</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9076</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2007-05-31T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__77">
<Fussgaengerzaehlstellen:OBJECTID>77</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>573502.47070000041 5938805.8797999993</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Berner Heerweg / Walddörfer Straße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9077</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2007-05-31T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__78">
<Fussgaengerzaehlstellen:OBJECTID>78</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>564854.65739999991 5923348.1791999992</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Bremer Straße SW Steinikestraße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9078</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2007-06-19T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__79">
<Fussgaengerzaehlstellen:OBJECTID>79</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>561851.0588999996 5935727.2993999999</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Plöner Straße O Schleswiger Straße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9079</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2007-06-26T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__80">
<Fussgaengerzaehlstellen:OBJECTID>80</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>572663.80549999978 5938859.8721999992</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Bullenkoppel / Am Stadtrand</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9080</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2008-01-15T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__81">
<Fussgaengerzaehlstellen:OBJECTID>81</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>574008.40230000019 5946788.6927000005</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Bergstedter Chaussee / Immenhorstweg</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9081</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2014-04-03T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__82">
<Fussgaengerzaehlstellen:OBJECTID>82</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>567440.97039999999 5943981.9196000006</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Moorreye / Flughafenstraße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9082</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2008-04-10T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__83">
<Fussgaengerzaehlstellen:OBJECTID>83</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>567890.58370000031 5931491.8856000006</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Peutestraße / Veddeler Brückenstraße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9083</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2008-04-01T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__84">
<Fussgaengerzaehlstellen:OBJECTID>84</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>567786.62810000032 5931675.8140999991</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Prielstraße / Veddeler Marktplatz</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9084</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2008-04-01T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__85">
<Fussgaengerzaehlstellen:OBJECTID>85</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>567734.64680000022 5931556.8622999992</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Tunnelstraße / Veddeler Marktplatz</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9085</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2008-04-01T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__86">
<Fussgaengerzaehlstellen:OBJECTID>86</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>577242.04040000029 5942328.4147999994</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Meiendorfer Straße / Grönländer Damm</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9086</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2008-05-06T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__87">
<Fussgaengerzaehlstellen:OBJECTID>87</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>576869.18059999961 5941834.6175999995</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Meiendorfer Straße SW Starckweg</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9087</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2008-05-06T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__88">
<Fussgaengerzaehlstellen:OBJECTID>88</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>563386.42320000008 5934259.8582000006</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Bernstorffstraße / Paul-Roosen-Straße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9088</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2008-07-03T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__89">
<Fussgaengerzaehlstellen:OBJECTID>89</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>565518.41339999996 5924574.6797000002</gml:pos>
</gml:Point></Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Veritaskai / Schellerdamm</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9089</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2008-09-10T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__90">
<Fussgaengerzaehlstellen:OBJECTID>90</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>569910.78679999989 5931951.6688999999</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Rothenburgstraße / Ausschläger Allee</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9090</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2008-12-02T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__91">
<Fussgaengerzaehlstellen:OBJECTID>91</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>561944.99480000045 5934115.9394000005</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Bahnhof Altona</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9091</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2002-04-27T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__92">
<Fussgaengerzaehlstellen:OBJECTID>92</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>571505.3161000004 5941821.7120999992</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Anderheitsallee W Bramfelder Chaussee</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9092</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2010-07-06T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__93">
<Fussgaengerzaehlstellen:OBJECTID>93</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>575169.82270000037 5928287.9691000003</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Unbenannter Weg Nr. 743002 (Veloroute 9) / Mittlerer Landweg</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9093</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2016-05-10T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__94">
<Fussgaengerzaehlstellen:OBJECTID>94</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>576516.30470000021 5940850.0155999996</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Oldenfelder Straße N Eggerskamp</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9094</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2009-04-02T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__95">
<Fussgaengerzaehlstellen:OBJECTID>95</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>564890.81670000032 5933814.0108000003</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Ludwig-Erhard-Straße O Englische Planke</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9095</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2009-05-05T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__96">
<Fussgaengerzaehlstellen:OBJECTID>96</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>566076.5867999997 5948385.1890999991</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Langenhorner Chaussee N Bärenhof</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9096</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2009-05-26T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__97">
<Fussgaengerzaehlstellen:OBJECTID>97</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>566086.58139999956 5948297.2239999995</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Langenhorner Chaussee / Stockflethweg</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9097</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2014-08-26T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__98">
<Fussgaengerzaehlstellen:OBJECTID>98</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>572121.94209999964 5934100.7763</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Washingtonallee SO Hasencleverstraße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9098</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2009-07-02T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__99">
<Fussgaengerzaehlstellen:OBJECTID>99</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>572265.88129999954 5933892.8566999994</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Washingtonallee SO Stengelestraße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9099</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2009-07-02T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__100">
<Fussgaengerzaehlstellen:OBJECTID>100</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>572410.81919999979 5933624.9609999992</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Washingtonallee SO Vierbergen</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9100</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2009-07-02T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__101">
<Fussgaengerzaehlstellen:OBJECTID>101</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>558248.55549999978 5939472.8676999994</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Franzosenkoppel / Spreestraße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9101</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2009-09-02T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__102">
<Fussgaengerzaehlstellen:OBJECTID>102</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>557352.87119999994 5937005.8649000004</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Flurstraße / Blomkamp</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9102</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2009-09-02T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__103">
<Fussgaengerzaehlstellen:OBJECTID>103</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>557340.87409999967 5936895.9088000003</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Geranienweg / Flurstraße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9103</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2009-09-02T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__104">
<Fussgaengerzaehlstellen:OBJECTID>104</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>565517.56379999965 5933609.0819000006</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Kleiner Burstah / Willy-Brandt-Straße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9104</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2009-09-17T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__105">
<Fussgaengerzaehlstellen:OBJECTID>105</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>557378.84169999976 5935852.3237999994</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Heinrich-Plett-Straße / Ostermeyerstraße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9105</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2009-10-06T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__106">
<Fussgaengerzaehlstellen:OBJECTID>106</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>551476.21300000045 5937119.9167999998</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Sülldorfer Landstraße / Sülldorfer Brooksweg</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9106</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2009-10-06T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__107">
<Fussgaengerzaehlstellen:OBJECTID>107</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>551409.23840000015 5937046.9470000006</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Alte Sülldorfer Landstraße / Sülldorfer Brooksweg</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9107</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2009-10-06T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__108">
<Fussgaengerzaehlstellen:OBJECTID>108</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>568112.50580000039 5932123.6304000001</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Billhorner Brückenstraße / Zweibrückenstraße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9108</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2009-10-29T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__109">
<Fussgaengerzaehlstellen:OBJECTID>109</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>568900.27830000035 5937307.5529999994</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Reesestraße / Barmbeker Markt</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9109</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2016-04-26T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__110">
<Fussgaengerzaehlstellen:OBJECTID>110</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>565135.56190000009 5924336.7807999998</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Neue Straße / Unterführung Buxtehuder Straße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9110</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2016-06-07T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__111">
<Fussgaengerzaehlstellen:OBJECTID>111</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>553356.37189999968 5931537.1086999997</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Neuenfelder Hauptdeich / Neuenfelder Damm</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9111</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2010-05-27T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__112">
<Fussgaengerzaehlstellen:OBJECTID>112</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>551793.0083999997 5932379.7990000006</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Cranzer Hauptdeich / Estedeich</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9112</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2010-05-27T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__113">
<Fussgaengerzaehlstellen:OBJECTID>113</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>562143.97090000007 5937452.6074999999</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Högenstraße / Steenwisch</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9113</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2010-06-02T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__114">
<Fussgaengerzaehlstellen:OBJECTID>114</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>580224.59449999966 5926835.5347000007</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Sander Damm / Vierlandenstraße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9114</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2010-06-22T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__115">
<Fussgaengerzaehlstellen:OBJECTID>115</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>564230.07380000036 5933451.1662000008</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Helgoländer Allee / St. Pauli Hafenstraße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9115</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2010-11-23T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__116">
<Fussgaengerzaehlstellen:OBJECTID>116</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>565193.53899999987 5924344.7765999995</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Karnapp NW Harburger Schloßstraße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9116</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2016-06-07T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__117">
<Fussgaengerzaehlstellen:OBJECTID>117</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>564456.98249999993 5933391.1863000002</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Hafentor / Ditmar-Koel-Straße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9117</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2010-11-23T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__118">
<Fussgaengerzaehlstellen:OBJECTID>118</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>561101.32299999986 5933651.1384999994</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Fischers Allee / Bernadottestraße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9118</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2016-05-25T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__119">
<Fussgaengerzaehlstellen:OBJECTID>119</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>571172.36400000006 5936730.7448999994</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Wendemuthstraße / Rüterstraße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9119</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2011-04-19T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__120">
<Fussgaengerzaehlstellen:OBJECTID>120</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>571140.37739999965 5936768.7302999999</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Wendemuthstraße / Wandsbeker Zollstraße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9120</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2011-04-19T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__121">
<Fussgaengerzaehlstellen:OBJECTID>121</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>566200.21580000035 5929023.8965000007</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Wegnr.10168 unben. Straße N Rotenhäuser Straße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9121</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2011-06-16T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__122">
<Fussgaengerzaehlstellen:OBJECTID>122</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>578280.35659999959 5926106.8573000003</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Nettelnburger Landweg S Nettelnburger Straße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9122</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2011-08-23T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__123">
<Fussgaengerzaehlstellen:OBJECTID>123</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>565574.36479999963 5922990.3096999992</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Wilstorfer Straße / Hannoversche Straße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9123</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2011-08-23T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__124">
<Fussgaengerzaehlstellen:OBJECTID>124</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>581022.31579999998 5929179.5878999997</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Binnenfeldredder NO Max-Eichholz-Ring (LG)</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9124</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2011-08-23T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__125">
<Fussgaengerzaehlstellen:OBJECTID>125</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>566602.20359999966 5937927.3443999998</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Dorotheenstraße / Krohnskamp</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9125</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2011-08-25T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__126">
<Fussgaengerzaehlstellen:OBJECTID>126</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>563791.34769999981 5939422.7956000008</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Kollaustraße / Osterfeldstraße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9126</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2011-08-25T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__127">
<Fussgaengerzaehlstellen:OBJECTID>127</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>565085.58189999964 5924340.7799999993</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Buxtehuder Straße NW Neue Straße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9127</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2016-06-07T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__128">
<Fussgaengerzaehlstellen:OBJECTID>128</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>564600.94550000038 5934613.6971000005</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Holstenglacis / Sievekingplatz</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9128</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2011-08-30T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__129">
<Fussgaengerzaehlstellen:OBJECTID>129</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>570876.47890000045 5936557.8186000008</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Wandsbeker Allee / Wandsbeker Marktstraße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9129</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2011-08-31T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__130">
<Fussgaengerzaehlstellen:OBJECTID>130</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>560401.59759999998 5933411.2456999999</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Elbchaussee W Rulantweg</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9130</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2011-09-08T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__131">
<Fussgaengerzaehlstellen:OBJECTID>131</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>573303.4561999999 5933172.1264999993</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Reclamstraße O Billstedter Platz (West)</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9131</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2011-10-18T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__132">
<Fussgaengerzaehlstellen:OBJECTID>132</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>573370.42879999988 5933133.1409000009</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Fritzschweg / Reclamstraße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9132</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2011-10-18T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__133">
<Fussgaengerzaehlstellen:OBJECTID>133</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>573401.41660000011 5933138.1383999996</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Billstedter Platz (Ost) N Reclamstraße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9133</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2011-10-18T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__134">
<Fussgaengerzaehlstellen:OBJECTID>134</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>568383.46040000021 5935883.1287999991</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Uferstraße NO Lerchenfeld</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9134</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2011-10-25T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__135">
<Fussgaengerzaehlstellen:OBJECTID>135</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>568303.49120000005 5935819.1556000002</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Lerchenfeld SW Uferstraße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9135</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2011-10-25T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__136">
<Fussgaengerzaehlstellen:OBJECTID>136</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>568855.27950000018 5936300.9546000008</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Wagnerstraße SW Uferstraße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9136</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2011-10-25T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__137">
<Fussgaengerzaehlstellen:OBJECTID>137</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>567342.87119999994 5935669.2313000001</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Schwanenwik S Hartwicusstraße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9137</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2011-10-27T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__138">
<Fussgaengerzaehlstellen:OBJECTID>138</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>566895.05750000011 5936152.0463999994</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Schöne Aussicht NW Auguststraße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9138</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2011-10-27T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__139">
<Fussgaengerzaehlstellen:OBJECTID>139</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>566457.24749999959 5937092.6791999992</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Bellevue N Scheffelstraße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9139</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2011-10-27T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__140">
<Fussgaengerzaehlstellen:OBJECTID>140</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>580328.55860000011 5927166.4012000002</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Vierlandenstraße / Bergedorfer Straße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9140</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2012-02-28T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__141">
<Fussgaengerzaehlstellen:OBJECTID>141</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>573435.46999999974 5937163.5349000003</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Jenfelder Straße SO Am Grundwasserwerk</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9141</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2012-04-12T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__142">
<Fussgaengerzaehlstellen:OBJECTID>142</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>568212.63659999985 5942388.5412000008</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Wellingsbüttler Landstraße / Fuhlsbüttler Straße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9142</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2012-04-26T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__143">
<Fussgaengerzaehlstellen:OBJECTID>143</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>567877.77070000023 5942436.5276999995</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Erdkampsweg / Brombeerweg</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9143</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2012-04-26T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__144">
<Fussgaengerzaehlstellen:OBJECTID>144</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>567872.77799999993 5942756.4003999997</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Hummelsbüttler Landstraße / Brombeerweg</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9144</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2012-04-26T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__145">
<Fussgaengerzaehlstellen:OBJECTID>145</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>567777.81290000025 5942578.4727999996</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Erdkampsweg / Hummelsbüttler Landstraße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9145</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2012-04-26T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__146">
<Fussgaengerzaehlstellen:OBJECTID>146</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>567800.80140000023 5942440.5274</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Erdkampsweg / Ratsmühlendamm</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9146</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2012-04-26T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__147">
<Fussgaengerzaehlstellen:OBJECTID>147</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>560508.65689999983 5939551.7988000009</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Kieler Straße / Sola-Bona-Park</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9147</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2012-05-30T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__148">
<Fussgaengerzaehlstellen:OBJECTID>148</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>564954.86899999995 5938492.1469000001</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Frickestraße / Martinistraße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9148</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2012-05-31T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__149">
<Fussgaengerzaehlstellen:OBJECTID>149</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>569769.88779999968 5934649.5968999993</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Hammer Steindamm S Bei der Hammer Kirche</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9149</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2016-10-13T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__150">
<Fussgaengerzaehlstellen:OBJECTID>150</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>571199.49859999958 5945467.2656999994</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Ulzburger Straße / Poppenbütteler Weg</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9150</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2012-08-28T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__151">
<Fussgaengerzaehlstellen:OBJECTID>151</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>571378.21040000021 5932423.4567000009</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Billbrookdeich / Liebigstraße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9151</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2012-11-01T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__152">
<Fussgaengerzaehlstellen:OBJECTID>152</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>569619.04779999983 5940658.2068000007</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Fritz-Flinte-Ring / Gründgensstraße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9153</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2012-11-08T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__153">
<Fussgaengerzaehlstellen:OBJECTID>153</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>569760.99069999997 5940624.2180000003</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Gropiusring / Gründgensstraße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9154</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2012-11-08T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__154">
<Fussgaengerzaehlstellen:OBJECTID>154</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>569994.8984000003 5940672.1950000003</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Schreyerring / Cesar-Klein-Ring (West)</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9155</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2012-11-08T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__155">
<Fussgaengerzaehlstellen:OBJECTID>155</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>570112.85209999979 5940709.1783000007</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Schreyerring / Cesar-Klein-Ring (Ost)</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9156</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2012-11-08T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__156">
<Fussgaengerzaehlstellen:OBJECTID>156</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>570248.79849999957 5940745.1616999991</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Gründgensstraße / Gustav-Seitz-Weg</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9157</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2012-11-08T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__157">
<Fussgaengerzaehlstellen:OBJECTID>157</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>565975.38769999985 5933984.9246999994</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Bergstraße / Mönckebergstraße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9158</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2012-12-19T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__158">
<Fussgaengerzaehlstellen:OBJECTID>158</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>568460.49949999992 5940079.4564999994</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Rübenkamp N Andreas-Knack-Ring</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9159</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2013-01-31T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__159">
<Fussgaengerzaehlstellen:OBJECTID>159</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>565781.37729999982 5928708.0293000005</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Gert-Schwämmle-Weg / Georg-Wilhelm-Straße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9160</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2013-04-16T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__160">
<Fussgaengerzaehlstellen:OBJECTID>160</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>556388.26840000041 5937795.5664000008</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Bornheide (vor Haus Nr. 43)</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9161</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2013-04-16T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__161">
<Fussgaengerzaehlstellen:OBJECTID>161</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>556390.27120000031 5938012.4800000004</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Bornheide S Kroonhorst (Süd)</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9162</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2013-04-16T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__162">
<Fussgaengerzaehlstellen:OBJECTID>162</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>556426.26190000027 5938318.3575999998</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Glückstädter Weg S Kroonhorst (Nord)</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9163</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2013-04-16T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__163">
<Fussgaengerzaehlstellen:OBJECTID>163</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>556443.2583999997 5938515.2788999993</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Bornheide N Kroonhorst (Nord)</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9164</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2013-04-25T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__164">
<Fussgaengerzaehlstellen:OBJECTID>164</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>561776.07129999995 5934672.7204999998</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Gaußstraße / Barnerstraße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9165</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2013-06-05T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__165">
<Fussgaengerzaehlstellen:OBJECTID>165</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>561898.01970000006 5934489.7913000006</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Julius-Leber-Straße O Barnerstraße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9166</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2013-06-05T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__166">
<Fussgaengerzaehlstellen:OBJECTID>166</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>562015.97300000023 5934506.7826000005</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Harkortstraße / Julius-Leber-Straße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9167</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2013-06-05T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__167">
<Fussgaengerzaehlstellen:OBJECTID>167</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>562052.95839999989 5934514.7787999995</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Haubachstraße NO Julius-Leber-Straße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9168</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2013-06-05T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__168">
<Fussgaengerzaehlstellen:OBJECTID>168</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>556083.37160000019 5936699.0080999993</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Rugenbarg / Blomkamp</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9169</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2013-06-19T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__169">
<Fussgaengerzaehlstellen:OBJECTID>169</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>576701.31149999984 5945674.0916000009</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Halenreie / Waldweg (Nord)</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9170</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2013-08-13T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__170">
<Fussgaengerzaehlstellen:OBJECTID>170</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>576711.30539999995 5945551.1403999999</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Halenreie / Waldweg (Süd)</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9171</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2013-08-13T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__171">
<Fussgaengerzaehlstellen:OBJECTID>171</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>565582.35869999975 5922811.3808999993</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Winsener Straße / Reeseberg</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9174</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2013-08-20T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__172">
<Fussgaengerzaehlstellen:OBJECTID>172</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>565479.6727 5939253.8347999994</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Salomon-Heine-Weg / Meenkwiese</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9176</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2013-12-03T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__173">
<Fussgaengerzaehlstellen:OBJECTID>173</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>562180.72119999956 5923283.2493999992</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Vahrenwinkelweg / Ehestorfer Weg</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9177</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2013-12-03T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__174">
<Fussgaengerzaehlstellen:OBJECTID>174</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>568811.36010000017 5940095.4442999996</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Fuhlsbüttler Straße / Elligersweg</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9178</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2014-03-19T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__175">
<Fussgaengerzaehlstellen:OBJECTID>175</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>566502.28270000033 5940289.4055000003</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Carl-Cohn-Straße / Alsterdorfer Straße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9179</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2014-03-20T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__176">
<Fussgaengerzaehlstellen:OBJECTID>176</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>572929.81039999984 5945513.2184999995</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Saseler Damm / Stadtbahnstraße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9180</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2014-03-27T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__177">
<Fussgaengerzaehlstellen:OBJECTID>177</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>573009.7790000001 5945536.2080000006</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Eekbusch N Stadtbahnstraße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9181</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2014-03-27T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__178">
<Fussgaengerzaehlstellen:OBJECTID>178</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>567218.91089999955 5935086.4653999992</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Lohmühlenstraße / Barcastraße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9183</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2014-06-11T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__179">
<Fussgaengerzaehlstellen:OBJECTID>179</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>566106.57689999975 5948505.1409000009</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Langenhorner Chaussee / Am Ochsenzoll</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9184</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2014-08-26T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__180">
<Fussgaengerzaehlstellen:OBJECTID>180</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>565930.46700000018 5937681.4535000008</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Leinpfad / Maria-Louisen-Straße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9185</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2016-07-05T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__181">
<Fussgaengerzaehlstellen:OBJECTID>181</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>568710.37770000007 5938740.9853000008</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Rübenkamp N Genslerstraße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9186</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2015-02-17T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__182">
<Fussgaengerzaehlstellen:OBJECTID>182</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>565394.67700000014 5937477.5436000004</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Eppendorfer Baum / Klosterstern</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9187</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2015-04-16T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__183">
<Fussgaengerzaehlstellen:OBJECTID>183</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>565442.65840000007 5937506.5311999992</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Oderfelder Straße / Klosterstern</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9188</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2015-04-16T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__184">
<Fussgaengerzaehlstellen:OBJECTID>184</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>565505.63269999996 5937468.5452999994</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>St. Benedictstraße / Klosterstern</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9189</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2015-04-16T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__185">
<Fussgaengerzaehlstellen:OBJECTID>185</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>565495.63540000003 5937396.5741000008</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Harvestehuder Weg / Klosterstern</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9190</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2015-04-16T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__186">
<Fussgaengerzaehlstellen:OBJECTID>186</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>565454.65139999986 5937374.5835999995</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Rothenbaumchaussee / Klosterstern</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9191</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2015-04-16T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__187">
<Fussgaengerzaehlstellen:OBJECTID>187</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>565393.67619999964 5937406.5717999991</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Jungfrauental / Klosterstern</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9192</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2015-04-16T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__188">
<Fussgaengerzaehlstellen:OBJECTID>188</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>565200.75650000013 5937614.4923</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Eppendorfer Baum / Isestraße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9193</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2015-04-16T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__189">
<Fussgaengerzaehlstellen:OBJECTID>189</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>570854.49289999995 5936868.6952</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Wandse Wanderweg (Querung Wandsbeker Allee)</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9194</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2015-07-09T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__190">
<Fussgaengerzaehlstellen:OBJECTID>190</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>568884.26819999982 5936318.9469000008</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Uferstraße NO Wagnerstraße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9196</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2015-12-01T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__191">
<Fussgaengerzaehlstellen:OBJECTID>191</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>563497.40170000028 5935627.3117999993</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Eimsbütteler Chaussee / Schulterblatt</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9197</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2015-09-03T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__192">
<Fussgaengerzaehlstellen:OBJECTID>192</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>566335.14960000012 5928274.1928000003</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Gert-Schwämmle-Weg NW Dratelnstraße (Unterführung Wilhelmsburger Reichsstraße, &quot;Loop&quot;)</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9198</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2015-09-29T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__193">
<Fussgaengerzaehlstellen:OBJECTID>193</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>566832.05339999963 5934393.7476000004</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Ellmenreichstraße O Kirchenallee</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9199</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2015-10-13T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__194">
<Fussgaengerzaehlstellen:OBJECTID>194</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>566772.07899999991 5934499.7063999996</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Kirchenallee N Ernst-Merck-Straße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9200</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2015-10-13T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__195">
<Fussgaengerzaehlstellen:OBJECTID>195</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>566668.12000000011 5934473.7184999995</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Holzdamm N Ernst-Merck-Straße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9201</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2015-10-13T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__196">
<Fussgaengerzaehlstellen:OBJECTID>196</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>566622.13769999985 5934439.7327999994</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Ernst-Merck-Straße SW Holzdamm</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9202</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2015-10-13T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__197">
<Fussgaengerzaehlstellen:OBJECTID>197</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>566471.19720000029 5934397.7520000003</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Glockengießerwall NW Ernst-Merck-Straße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9203</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2015-10-13T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__198">
<Fussgaengerzaehlstellen:OBJECTID>198</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>566447.20550000016 5934327.7803000007</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Georgsplatz SW Glockengießerwall</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9204</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2015-10-13T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__199">
<Fussgaengerzaehlstellen:OBJECTID>199</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>566578.15160000045 5934221.8202999998</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Spitaler Straße SW Steintorwall</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9205</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2015-10-13T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__200">
<Fussgaengerzaehlstellen:OBJECTID>200</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>566578.14979999978 5934112.8637000006</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Mönckebergstraße W Steintorwall</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9206</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2015-10-13T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__201">
<Fussgaengerzaehlstellen:OBJECTID>201</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>566644.12310000043 5934085.8734000009</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Steintorwall S Mönckebergstraße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9207</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2015-10-13T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__202">
<Fussgaengerzaehlstellen:OBJECTID>202</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>566694.10400000028 5934131.8541999999</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Steintordamm O Steintorwall</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9208</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2015-10-13T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__203">
<Fussgaengerzaehlstellen:OBJECTID>203</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>566819.05379999988 5934108.8613000009</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Julius-Kober-Weg S Steintordamm</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9209</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2015-10-13T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__204">
<Fussgaengerzaehlstellen:OBJECTID>204</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>566910.01800000016 5934133.8498</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Brockesstraße S Steintorplatz</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9210</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2015-10-13T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__205">
<Fussgaengerzaehlstellen:OBJECTID>205</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>566945.00409999955 5934131.8500999995</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>ZOB (Hbf) Zugang O Brockesstraße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9211</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2015-10-13T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__206">
<Fussgaengerzaehlstellen:OBJECTID>206</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>566959.99899999984 5934185.8282999992</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Adenauerallee O Steindamm</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9212</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2015-10-13T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__207">
<Fussgaengerzaehlstellen:OBJECTID>207</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>566935.00970000029 5934230.8107999992</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Steindamm NO Steintorplatz</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9213</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2015-10-13T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__208">
<Fussgaengerzaehlstellen:OBJECTID>208</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>566881.03129999992 5934239.8081</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Steintorweg N Steintorplatz</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9214</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2015-10-13T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__209">
<Fussgaengerzaehlstellen:OBJECTID>209</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>566835.05099999998 5934321.7763</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Bremer Reihe O Kirchenallee</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9215</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2015-10-13T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__210">
<Fussgaengerzaehlstellen:OBJECTID>210</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>566757.08160000015 5934295.7879000008</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Hauptbahnhof - Zugang Ostseite (Mitte)</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9216</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2015-10-13T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__211">
<Fussgaengerzaehlstellen:OBJECTID>211</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>566751.08469999954 5934334.7725000009</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Hauptbahnhof - Zugang Ostseite (Nord)</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9217</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2015-10-13T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__212">
<Fussgaengerzaehlstellen:OBJECTID>212</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>566609.14020000026 5934278.7971000001</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Hauptbahnhof - Zugang Westseite (Nord)</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9218</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2015-10-13T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__213">
<Fussgaengerzaehlstellen:OBJECTID>213</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>566657.11899999995 5934150.8473000005</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Hauptbahnhof - Zugang Westseite (Süd)</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9219</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2015-10-13T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__214">
<Fussgaengerzaehlstellen:OBJECTID>214</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>566790.06659999955 5934183.8319000006</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Hauptbahnhof - Zugang Ostseite (Süd)</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9220</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2015-10-13T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__215">
<Fussgaengerzaehlstellen:OBJECTID>215</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>569733.40409999993 5937829.4296000004</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Krausestraße / Lämmersieth</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9152</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2016-09-13T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__216">
<Fussgaengerzaehlstellen:OBJECTID>216</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>566046.69469999988 5938162.8325999994</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Leinpfad / Goernestraße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9172</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2016-07-05T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__217">
<Fussgaengerzaehlstellen:OBJECTID>217</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>563980.7993999999 5935255.8464000002</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Schanzenstraße / Lagerstraße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9173</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2016-06-07T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__218">
<Fussgaengerzaehlstellen:OBJECTID>218</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>565983.58370000031 5939699.1960000005</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Alsterdorfer Straße / Braamkamp</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9175</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2016-10-11T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__219">
<Fussgaengerzaehlstellen:OBJECTID>219</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>566328.60030000005 5939586.4807999991</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Braamkamp / Krochmannstraße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9182</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2016-10-11T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__220">
<Fussgaengerzaehlstellen:OBJECTID>220</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>569847.60109999962 5935011.9857999999</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Hammer Steindamm / Moorende</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9195</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2016-10-13T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__221">
<Fussgaengerzaehlstellen:OBJECTID>221</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>566374.33860000037 5938050.4003999997</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Sierichstraße / Maria-Louisen-Straße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9221</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2016-09-27T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__222">
<Fussgaengerzaehlstellen:OBJECTID>222</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>566290.71109999996 5934544.5448000003</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Lombardsbrücke / Ballindamm</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9225</Fussgaengerzaehlstellen:Zaehlstelle>
<Fussgaengerzaehlstellen:Letzte_Zaehlung>2014-07-08T00:00:00</Fussgaengerzaehlstellen:Letzte_Zaehlung>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__223">
<Fussgaengerzaehlstellen:OBJECTID>223</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>569757.12330000009 5940487.4112999998</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Alfred-Mahlau-Weg / Steilshooper Allee</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9222</Fussgaengerzaehlstellen:Zaehlstelle>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__224">
<Fussgaengerzaehlstellen:OBJECTID>224</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>569960.19139999989 5940484.1040000003</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Steilshooper Allee / Steilshooper Straße</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9223</Fussgaengerzaehlstellen:Zaehlstelle>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
<gml:featureMember>
<Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen gml:id="F3__225">
<Fussgaengerzaehlstellen:OBJECTID>225</Fussgaengerzaehlstellen:OBJECTID>
<Fussgaengerzaehlstellen:Shape>
<gml:Point>
<gml:pos>570269.75449999981 5940507.5857999995</gml:pos>
</gml:Point>
</Fussgaengerzaehlstellen:Shape>
<Fussgaengerzaehlstellen:Bezeichnung>Gustav-Seitz-Weg / Steilshooper Allee</Fussgaengerzaehlstellen:Bezeichnung>
<Fussgaengerzaehlstellen:Zaehlstelle>9224</Fussgaengerzaehlstellen:Zaehlstelle>
</Fussgaengerzaehlstellen:Fussgaenger_Bedarfszaehlstellen>
</gml:featureMember>
</wfs:FeatureCollection>